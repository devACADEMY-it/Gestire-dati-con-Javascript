/*
 * Gestire dati con Javascript
 * Definire oggetti
 *
 * Disponibile su devACADEMY.it
 */

var persona = {
	nome : "Giovanni",
	cognome : "Rossi",
	eta : 25
};

document.write(persona.nome);

document.write("<br>");

document.write(persona.nome+" "+persona.cognome);

document.write("<br>");

persona.stato_civile="coniugato";

document.write(persona.nome+" "+persona.cognome+", "+persona.stato_civile);

document.write("<br>");

var persona2 = {
	nome : "Giovanni",
	cognome : "Rossi",
	eta : 25, 
	residenza : {
			indirizzo : "via Manzoni, 54",
			CAP : "10122",
			citta : "Torino"
	}
};

document.write(persona2.nome+" "+persona2.cognome+" risiede a "+persona2.residenza.citta);