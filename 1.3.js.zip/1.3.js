/*
 * Gestire dati con Javascript
 * Metodi per gli oggetti
 *
 * Disponibile su devACADEMY.it
 */

var persona = {
	nome : "Giovanni",
	cognome : "Rossi",
	eta : 16, 
	residenza : {
			indirizzo : "via Manzoni, 54",
			CAP : "10122",
			citta : "Torino"
	}
};

persona.nomeCompleto= function() { return persona.nome+" "+persona.cognome};

persona.maggiorenne = function() {return persona.eta>=18};



document.write("<br>");

if( persona.maggiorenne() )
	document.write(persona.nomeCompleto()+", maggiorenne");
else
	document.write(persona.nomeCompleto()+", minorenne");