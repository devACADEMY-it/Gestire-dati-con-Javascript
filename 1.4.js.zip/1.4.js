/*
 * Gestire dati con Javascript
 * Classi e ereditarietà (I)
 *
 * Disponibile su devACADEMY.it
 */
 
class Persona {
	constructor(nome, cognome)
	{
		this.nome = nome;
		this.cognome = cognome;
	}
	
	nomeCompleto()
	{
		return this.nome+" "+this.cognome;
	}
	
	set eta(e)
	{
		this._eta=e;
	}
	
	get eta()
	{
		return this._eta;
	}
}

tizio = new Persona("Giulio", "Neri");

nc = tizio.nomeCompleto();

document.write(nc);

tizio.eta = 19;

document.write("<br>");

document.write(tizio.eta);