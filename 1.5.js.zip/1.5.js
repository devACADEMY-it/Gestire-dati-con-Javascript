/*
 * Gestire dati con Javascript
 * Classi e ereditarietà (II)
 *
 * Disponibile su devACADEMY.it
 */
 
 class Persona {
	constructor(nome, cognome)
	{
		this.nome = nome;
		this.cognome = cognome;
	}
	
	nomeCompleto()
	{
		return this.nome+" "+this.cognome;
	}
	
	set eta(e)
	{
		this._eta=e;
	}
	
	get eta()
	{
		return this._eta;
	}
}

class Studente extends Persona
{
	constructor(nome, cognome, corso)
	{
		super(nome, cognome);
		this.corso = corso;
	}
	
	get cosaStudia()
	{
		return this.corso;
	}
}

allievo = new Studente("Sabrina", "Gialli", "Storia antica");

document.write(allievo.cosaStudia+"<br>");

document.write(allievo.nomeCompleto());