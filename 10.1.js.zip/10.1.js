/*
 * Gestire dati con Javascript
 * Funzioni arrow
 *
 * Disponibile su devACADEMY.it
 */

raddoppia = function(a)
{
	return a*2;
}

document.write(raddoppia(5));
document.write("<br><br>");

raddoppia_freccia = (a) => a*2;

document.write(raddoppia_freccia(7));
document.write("<br><br>");

moltiplica = (a,b) => a*b;

document.write(moltiplica(2, 6));
document.write("<br><br>");

vettore = [5, 9, 2, 14, 7, 12];

/*vettore.forEach(
	function(x)
	{
		document.write(x+"<br>");
	}
);*/

vettore.forEach( x => document.write(x+"<br>"));