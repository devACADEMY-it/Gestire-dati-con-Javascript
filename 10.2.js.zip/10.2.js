/*
 * Gestire dati con Javascript
 * Generators
 *
 * Disponibile su devACADEMY.it
 */

function* genera()
{
	yield 23;
	yield 51;
	yield 12;
}

generatore = genera();

document.write(generatore.next().value);
document.write("<br>");
document.write(generatore.next().value);
document.write("<br>");
document.write(generatore.next().value);
document.write("<br>");
document.write(generatore.next().value);
document.write("<br>");

document.write("<br><br>");

function* aCaso()
{
	while(true)
		yield Math.random();
}

generatore = aCaso();

document.write(generatore.next().value);
document.write("<br>");
document.write(generatore.next().value);
document.write("<br>");
document.write(generatore.next().value);
document.write("<br>");
document.write(generatore.next().value);
document.write("<br>");


document.write("<br><br>");

function* aCaso2(x)
{
	while(true)
		yield Math.random()*x;
}


generatore = aCaso2(7);

document.write(generatore.next().value);
document.write("<br>");
document.write(generatore.next().value);
document.write("<br>");
document.write(generatore.next().value);
document.write("<br>");
document.write(generatore.next().value);
document.write("<br>");



document.write("<br><br>");

function* aCaso3(x)
{
	max = 5;
	quanti = 0;
	while(max>quanti++)
		yield Math.random()*x;
}


generatore = aCaso3(4);

document.write(generatore.next().value);
document.write("<br>");
document.write(generatore.next().value);
document.write("<br>");
document.write(generatore.next().value);
document.write("<br>");
document.write(generatore.next().value);
document.write("<br>");
document.write(generatore.next().value);
document.write("<br>");
document.write(generatore.next().value);
document.write("<br>");
document.write(generatore.next().value);
document.write("<br>");
document.write(generatore.next().value);
document.write("<br>");