/*
 * Gestire dati con Javascript
 * Conversioni JSON/oggetti
 *
 * Disponibile su devACADEMY.it
 */

 oggetto = {
	"nome": "Antonio",
	"cognome": "Verdi"
 };

 serializzato = JSON.stringify(oggetto);
 
 document.write(serializzato);
 document.write("<br><br>");
 document.write(oggetto.cognome);
 
 document.write("<br><br>");
 document.write(serializzato.length);
 
 deserializzato = JSON.parse(serializzato);
 
 document.write("<br><br>");
 document.write(deserializzato.nome);
 
 var array = [
	{
		"nome": "Antonio",
		"cognome": "Verdi"
	},
	{
		"nome": "Luca",
		"cognome": "Gialli"
	},
	{
		"nome": "Simone",
		"cognome": "Rossi"
	}
 ];
 
 serializzato = JSON.stringify(array);
 
 document.write("<br><br>");
 document.write(serializzato);
 
 deserializzato = JSON.parse(serializzato);
 
 document.write("<br><br>");
 document.write(deserializzato[1].cognome);