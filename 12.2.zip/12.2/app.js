/*
 * Gestire dati con Javascript
 * Definizione degli oggetti
 *
 * Disponibile su devACADEMY.it
 */

giocatore1=new Giocatore("Alessio", "Bianchi");
giocatore2=new Giocatore("Roberto", "Neri");
giocatore3=new Giocatore("Marco", "Rossi");

allenatore=new Allenatore("Gigi", "Grigi", 2008);

squadra=new Squadra("Le aquile", allenatore);