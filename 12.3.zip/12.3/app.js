/*
 * Gestire dati con Javascript
 * Funzionalità
 *
 * Disponibile su devACADEMY.it
 */

giocatore1=new Giocatore("Alessio", "Bianchi");
giocatore2=new Giocatore("Roberto", "Neri");
giocatore3=new Giocatore("Marco", "Rossi");

allenatore=new Allenatore("Gigi", "Grigi", 2008);

squadra=new Squadra("Le aquile", allenatore);

giocatore1.nuoviPunti(3);
giocatore1.nuoviPunti(2);

giocatore2.nuoviPunti(7);

giocatore3.nuoviPunti(1);
giocatore3.nuoviPunti(1);

squadra.nuovoGiocatore(giocatore1);
squadra.nuovoGiocatore(giocatore2);
squadra.nuovoGiocatore(giocatore3);