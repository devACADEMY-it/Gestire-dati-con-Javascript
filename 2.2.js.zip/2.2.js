/*
 * Gestire dati con Javascript
 * Definizione di array
 *
 * Disponibile su devACADEMY.it
 */

//var numeri = new Array(12, 6, 9, 32, 14, 21, 5);

var numeri= [12, 6, 9, 32, 14, 21, 5];

document.write(numeri);

document.write("<br>");

var terzo = numeri[2];

document.write(terzo);

document.write("<br>");

numeri[2] = 11;

document.write(numeri);

document.write("<br>");

document.write(numeri.length);

document.write("<br>");

numeri.push(44);

document.write(numeri);

document.write("<br>");

var valore = numeri.pop();

document.write(valore);

document.write("<br>");

document.write(numeri);

document.write("<br>");