/*
 * Gestire dati con Javascript
 * Introduzione alle stringhe
 *
 * Disponibile su devACADEMY.it
 */

var stringa = "Meglio un uovo oggi che una gallina domani";

document.write(stringa);

document.write("<br><br>");

document.write("Proverbio ... "+stringa);

document.write("<br><br>");

document.write(stringa.length);

document.write("<br><br>");

document.write(stringa[8]);

document.write("<br><br>");

document.write(stringa.charAt(8));

document.write("<br><br>");

document.write(stringa.concat(" ... consiglio molto saggio"));