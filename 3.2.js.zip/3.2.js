/*
 * Gestire dati con Javascript
 * Metodi per le stringhe (I)
 *
 * Disponibile su devACADEMY.it
 */

var stringa = "Meglio un uovo oggi che una gallina domani";

document.write(stringa.toLowerCase());

document.write("<br><br>");

document.write(stringa.toUpperCase());

document.write("<br><br>");

document.write("1234".repeat(4));

document.write("<br><br>");

document.write(stringa.indexOf("o")); // 5

document.write("<br><br>");

document.write(stringa.indexOf("o", 6));

document.write("<br><br>");

document.write(stringa.lastIndexOf("o")); // 37

document.write("<br><br>");

document.write(stringa.lastIndexOf("o", 36));

document.write("<br><br>");

document.write(stringa.startsWith("M"));

document.write("<br><br>");

document.write(stringa.endsWith("w"));

document.write("<br><br>");

document.write(stringa.includes("li"));