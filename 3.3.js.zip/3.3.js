/*
 * Gestire dati con Javascript
 * Metodi per le stringhe (II)
 *
 * Disponibile su devACADEMY.it
 */

var stringa = "Meglio un uovo oggi che una gallina domani";

document.write(stringa.replace("gallina", "papera"));

document.write("<br><br>");

document.write(stringa.slice(15));

document.write("<br><br>");

document.write(stringa.slice(15, 22));

document.write("<br><br>");

document.write(stringa.substring(15));

document.write("<br><br>");

document.write(stringa.substring(15, 22));

document.write("<br><br>");

document.write(stringa.substr(15));

document.write("<br><br>");

document.write(stringa.substr(15, 5));

document.write("<br><br>");

var parti=stringa.split(" ");

document.write(parti);

document.write("<br><br>");

document.write(parti[3]);