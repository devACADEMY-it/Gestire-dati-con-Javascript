/*
 * Gestire dati con Javascript
 * Template String
 *
 * Disponibile su devACADEMY.it
 */

prezzo = 88;
//messaggio = "Il prezzo IVA esclusa è "+prezzo;

//messaggio = `Il prezzo IVA esclusa è ${prezzo} <br>`;

//messaggio = `Il prezzo IVA inclusa è ${prezzo * 1.22} <br>`;

function prezzoFinale(strings, a)
{
	return "Argomenti: <br>- "+strings[0]+"<br>- "+strings[1]+"<br>- "+a;
}

messaggio = prezzoFinale`Il prezzo è ${prezzo * 1.22}, IVA inclusa <br>`;

document.write(messaggio);