/*
 * Gestire dati con Javascript
 * Espressioni regolari
 *
 * Disponibile su devACADEMY.it
 */

var telefono="011--786928";

//var expr = /.+/;

var expr = /^[0-9]{3}-?[0-9]{5,8}$/;

res=expr.test(telefono);

document.write(res);