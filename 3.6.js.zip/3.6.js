/*
 * Gestire dati con Javascript
 * Esempio riepilogo: analisi di un testo
 *
 * Disponibile su devACADEMY.it
 */

var testo = `il mio migliore amico è Saverio, il fratello di Andrea,  
              molto intelligente ma non quanto Simona`;
				
document.write(testo);

document.write("<br><br>");

var expr = /[A-Z][a-z]+/g;

res = testo.search(expr);
document.write(res);

document.write("<br><br>");

res = testo.match(expr);

document.write("Trovate "+res.length+" occorrenze <br>");
document.write(res);

document.write("<br><br>");

document.write(res[1]);

document.write("<br><br>");

document.write(expr.exec(testo));

document.write("<br>");

document.write(expr.exec(testo));

document.write("<br>");

document.write(expr.exec(testo));