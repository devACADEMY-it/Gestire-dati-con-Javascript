/*
 * Gestire dati con Javascript
 * Numeri in Javascript
 *
 * Disponibile su devACADEMY.it
 */

var a=8;
var b="2";
var c=45.869;

res=a+parseInt(b);

document.write(c.toFixed(1));

/*if (isNaN(res))
	document.write("Non un numero");
else
    document.write("si tratta di un numero");*/  