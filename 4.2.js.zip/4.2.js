/*
 * Gestire dati con Javascript
 * Oggetto Math
 *
 * Disponibile su devACADEMY.it
 */

var numero = 44.589;

var ris= Math.floor(numero);

document.write(ris);

document.write("<br>");

ris= Math.ceil(numero);

document.write(ris);

document.write("<br>");

ris = Math.min(45, 2, 7 , 1, 89 , 43);

document.write(ris);

document.write("<br>");

ris = Math.max(45, 2, 7 , 1, 89 , 43);

document.write(ris);

document.write("<br>");

ris = Math.random();

document.write(ris);

document.write("<br>");

ris = Math.pow(3, 2);

document.write(ris);

document.write("<br>");

ris = Math.sqrt(49);

document.write(ris);