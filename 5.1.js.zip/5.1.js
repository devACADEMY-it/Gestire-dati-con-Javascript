/*
 * Gestire dati con Javascript
 * Date in Javascript
 *
 * Disponibile su devACADEMY.it
 */

var oggi = new Date();

document.write(oggi);

document.write("<br>");

oggi = new Date().toLocaleString('it-IT');

document.write(oggi);

document.write("<br>");

var unGiorno = new Date(2016, 6, 21, 12, 15, 0, 0);

document.write(unGiorno);

document.write("<br>");