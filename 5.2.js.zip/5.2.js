/*
 * Gestire dati con Javascript
 * Manipolazione di date
 *
 * Disponibile su devACADEMY.it
 */

var oggi = new Date();

document.write(oggi);

document.write("<br>");

var unGiorno = new Date(2016, 6, 21, 12, 15, 0, 0);

document.write(unGiorno);

document.write("<br>");

if (unGiorno < oggi)
	document.write("unGiorno è prima di oggi <br>");
else
	document.write("unGiorno non è prima di oggi <br>");

document.write(oggi.getFullYear());

document.write("<br>");

document.write(oggi.getMonth());

document.write("<br>");

document.write(oggi.getMinutes());

document.write("<br>");

document.write(oggi.toDateString());

document.write("<br>");

document.write(oggi.toTimeString());

document.write("<br>");

document.write(oggi.toLocaleDateString());

document.write("<br>");

document.write(oggi.toLocaleTimeString());

document.write("<br>");