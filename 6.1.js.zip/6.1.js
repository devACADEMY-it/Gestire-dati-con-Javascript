/*
 * Gestire dati con Javascript
 * Manipolazione di array
 *
 * Disponibile su devACADEMY.it
 */

var numeri= [12, 6, 9, 32, 14, 9, 5];

document.write(numeri);
document.write("<br><br>");

document.write("Indice di 9 ... "+numeri.indexOf(9));
document.write("<br><br>");

document.write("Indice di 87 ... "+numeri.indexOf(87));
document.write("<br><br>");

document.write(numeri.join(" ; "));
document.write("<br><br>");

numeri.unshift(77);
document.write(numeri);
document.write("<br><br>");

numeri.shift();
document.write(numeri);
document.write("<br><br>");

var altroNumeri = [112, 99, 7, 28];
document.write(numeri.concat(altroNumeri));
document.write("<br><br>");

pari = numeri.filter(function(e) {return e%2 == 0; });
document.write(pari);
document.write("<br><br>");

raddoppiati = numeri.map(function(e) {return e*2; });
document.write(raddoppiati);
document.write("<br><br>");

document.write(numeri.reverse());
document.write("<br><br>");

document.write(numeri.includes(32));
document.write("<br><br>");

document.write(numeri.includes(329));
document.write("<br><br>");