/*
 * Gestire dati con Javascript
 * Cicli e array
 *
 * Disponibile su devACADEMY.it
 */

var numeri = [12, 6, 9, 32, 14, 9, 5];

document.write(numeri);
document.write("<br><br>");

cont = 0;
while (cont<numeri.length)
	document.write(numeri[cont++]+"<br>");

document.write("<br><br>");

for (i=0; i<numeri.length; i++)
	document.write(numeri[i]+"<br>");

document.write("<br><br>");

for (n in numeri)
	document.write(numeri[n]+"<br>");

document.write("<br><br>");

for (n of numeri)
	document.write(n+"<br>");

document.write("<br><br>");

numeri.forEach( function(e){document.write(e+"<br>");} );