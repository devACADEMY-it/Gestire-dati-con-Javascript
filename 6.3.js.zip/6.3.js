/*
 * Gestire dati con Javascript
 * Esempio riepilogo: ricerca di elementi
 *
 * Disponibile su devACADEMY.it
 */

var sviluppatori= [
  { nominativo:"Elena Rossi", 
    competenze: "Java, PHP, Linux"},
  { nominativo:"Ivano Neri", 
    competenze: "Java, Android"},
  { nominativo:"Simone Verdi", 
    competenze: "HTML, CSS, Javascript"},
  { nominativo:"Miriam Rossi", 
    competenze: "PHP"},
  { nominativo:"Eva Bianchi", 
    competenze: "C#"},
  { nominativo:"Nicola Neri", 
    competenze: "Java, Android, PHP"},
];

selezionati = sviluppatori.filter(
	function (e)
	{
		return e.competenze.split(",").length>=3;
	}
);

selezionati.forEach(
	function(e)
	{
		document.write(e.nominativo+"<br>");
	}
);