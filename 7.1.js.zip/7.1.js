/*
 * Gestire dati con Javascript
 * L’oggetto Error
 *
 * Disponibile su devACADEMY.it
 */

numeri = [12, 5, 8];

try {
numeri.join("-");
document.write("Fine TRY<br>");
}
catch(err)
{
	document.write(err.name+"<br>");
	document.write(err.message+"<br>");
}
finally
{
	document.write("Interviene sempre<br>");
}

document.write("<br><br>FINE script<br><br>");