/*
 * Gestire dati con Javascript
 * Errori personalizzati
 *
 * Disponibile su devACADEMY.it
 */

numeri = [12, 5, 8];

class MyError extends Error
{
	constructor(msg)
	{
		super(msg);
		this.name="MyError";
		this.quando = new Date();
	}
}

try {
	if (numeri.length<5)
		throw new MyError("Troppi pochi elementi");
	document.write("Elementi sufficienti<br>");
}
catch(err)
{
	document.write(err.name+"<br>");
	document.write(err.message+"<br>");
	document.write(err.quando+"<br>");
}

document.write("<br><br>FINE script<br><br>");