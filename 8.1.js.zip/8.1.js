/*
 * Gestire dati con Javascript
 * Array tipizzati
 *
 * Disponibile su devACADEMY.it
 */

var buffer = new Uint8ClampedArray(10);

buffer[0] = 25;
buffer[1] = 100;
buffer[2] = -24;
buffer[3] = 2500;

for (x of buffer)
	document.write(x+"<br>");