/*
 * Gestire dati con Javascript
 * Set
 *
 * Disponibile su devACADEMY.it
 */

insieme = new Set();

insieme.add(15);
insieme.add(28);
insieme.add(31);
insieme.add(54);
insieme.add(31);

document.write(`L'insieme contiene ${insieme.size} elementi<br><br>`);

for (x of insieme)
	document.write(x+"<br>");

insieme.delete(31);

if (insieme.has(31))
	document.write("Esiste<br><br>");
else
	document.write("Non esiste <br><br>");

insieme.clear();

document.write(`L'insieme contiene ${insieme.size} elementi<br><br>`);