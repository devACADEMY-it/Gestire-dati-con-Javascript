/*
 * Gestire dati con Javascript
 * Map
 *
 * Disponibile su devACADEMY.it
 */

mappa = new Map();

mappa.set("Italiano", 8);
mappa.set("Storia", 9);
mappa.set("Matematica", 6);

voto = mappa.get("Storia");

document.write(voto);
document.write("<br><br>");

for (x of mappa.keys())
	document.write(x+"<br>");

document.write("<br><br>");

for (x of mappa.values())
	document.write(x+"<br>");

document.write("<br><br>");

for (x of mappa.entries())
	document.write(x[0]+" - "+x[1]+"<br>");

document.write("<br><br>");

if (mappa.has("Astrofisica"))
	document.write("Voto : "+mappa.get("Astrofisica"));
else
	document.write("Non si studia Astrofisica");