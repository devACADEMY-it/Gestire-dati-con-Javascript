/*
 * Gestire dati con Javascript
 * Strutture dati weak-link
 *
 * Disponibile su devACADEMY.it
 */

wm = new WeakMap();

chiave = {nome: "Ivan"};

wm.set(chiave, 4);

document.write(wm.has(chiave));
document.write("<br><br>");

document.write(wm.get(chiave));
document.write("<br><br>");

ws = new WeakSet();

ws.add(chiave);
document.write(ws.has(chiave));

document.write("<br><br>");
ws.delete(chiave);
document.write(ws.has(chiave));