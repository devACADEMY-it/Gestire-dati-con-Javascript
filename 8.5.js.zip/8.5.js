/*
 * Gestire dati con Javascript
 * Esempio riepilogo: reti di informazioni
 *
 * Disponibile su devACADEMY.it
 */

var nomi = [
	{
		nome: "Antonio",
		cognome: "Verdi"
	},
	{
		nome: "Luca",
		cognome: "Gialli"
	},
	{
		nome: "Simone",
		cognome: "Rossi"
	},
	{
		nome: "Silvia",
		cognome: "Neri"
	},
	{
		nome: "Enrico",
		cognome: "Bianchi"
	},
	{
		nome: "Ernesto",
		cognome: "Gialli"
	},
	{
		nome: "Elisa",
		cognome: "Neri"
	},
	{
		nome: "Vincenzo",
		cognome: "Rossi"
	}
];


mappa = new Map();

for (o of nomi)
{
	if (!mappa.has(o.cognome))
		mappa.set(o.cognome, new Set());
	mappa.get(o.cognome).add(o);
}

for (c of mappa.keys())
	document.write(c+"<br>");

document.write("<br><br>");

for (c of mappa.keys())
	document.write(`${c} - ${mappa.get(c).size}<br>`);

document.write("<br><br>");

for (v of mappa.get("Gialli"))
	document.write(`${v.cognome} ${v.nome} <br>`);