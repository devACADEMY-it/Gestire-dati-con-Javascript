/*
 * Gestire dati con Javascript
 * Esempio riepilogo: strutturazione del codice in moduli
 *
 * Disponibile su devACADEMY.it
 */

const ALIQUOTA = 22;

class Cassa
{
	constructor()
	{
		this.prezzi=[];
	}
	
	aggiungiPrezzo(prezzo)
	{
		this.prezzi.push(prezzo);
	}
	
	get totale()
	{
		var totale = 0;
		
		for (let p of this.prezzi)
			totale+=p;
		
		totale*=(100+ALIQUOTA)/100;
		return totale.toFixed(2);
		
	}
}

export {Cassa};